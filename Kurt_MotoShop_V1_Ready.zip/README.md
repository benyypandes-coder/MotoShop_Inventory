# KURT MOTOSHOP V.1

A clean, racing-inspired offline Android inventory app for a motorcycle shop.

## Build on GitHub

1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Keep `.github/workflows/build-apk.yml`.
3. Open GitHub Actions.
4. Run **Build Kurt MotoShop APK** manually.
5. When it succeeds, open the run and download **Kurt-MotoShop-V1-APK** from Artifacts.

## Included

- Red/black racing UI
- Products / Parts count
- Services / Labor count
- Add Product
- Add Service
- Local offline storage using SharedPreferences
- Android Gradle project structure
- GitHub Actions APK build
