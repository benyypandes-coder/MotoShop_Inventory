package com.kurtmotoshop.v1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private LinearLayout root, content;
    private TextView productCount, serviceCount, modeText;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(5, 6, 8);
    private final int CARD = Color.rgb(14, 17, 21);
    private final int RED = Color.rgb(235, 25, 35);
    private final int BLUE = Color.rgb(20, 120, 235);
    private final int GREEN = Color.rgb(30, 210, 95);
    private final int ORANGE = Color.rgb(255, 145, 25);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(165, 169, 176);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("inventory", MODE_PRIVATE);
        buildUI();
    }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable bg(int color, float radius, int stroke, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }

    private TextView sectionTitle(String s) {
        TextView t = tv(s, 18, WHITE, true);
        t.setPadding(20, 24, 20, 10);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout box(int color, int strokeColor) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18, 16, 18, 16);
        l.setBackground(bg(color, 28, 2, strokeColor));
        return l;
    }

    private TextView button(String text, int color) {
        TextView b = tv(text, 15, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(12, 15, 12, 15);
        b.setBackground(bg(color, 22, 0, color));
        return b;
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 10, 16, 20);
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout header = row();
        header.setPadding(4, 8, 4, 8);

        TextView logo = tv("K3", 28, RED, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(bg(Color.rgb(18,20,24), 18, 2, RED));
        header.addView(logo, new LinearLayout.LayoutParams(58,58));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(12,0,0,0);
        TextView name = tv("KURT MOTOSHOP", 22, WHITE, true);
        TextView sub = tv("RIDE  •  BUILD  •  TRUST", 10, MUTED, false);
        brand.addView(name); brand.addView(sub);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        TextView gear = tv("⚙", 27, WHITE, false);
        gear.setGravity(Gravity.CENTER);
        header.addView(gear, new LinearLayout.LayoutParams(55,55));
        root.addView(header);

        TextView line = tv("DASHBOARD", 28, WHITE, true);
        line.setPadding(4, 22, 4, 2);
        root.addView(line);

        modeText = tv("●  OFFLINE MODE     Local data is saved on this phone", 13, GREEN, true);
        modeText.setPadding(14, 14, 14, 14);
        modeText.setBackground(bg(Color.rgb(13, 27, 19), 20, 1, GREEN));
        root.addView(modeText);

        LinearLayout stats = row();
        stats.setPadding(0, 14, 0, 0);
        LinearLayout pStat = statCard("📦", "PRODUCTS / PARTS", RED, true);
        LinearLayout sStat = statCard("🔧", "SERVICES / LABOR", BLUE, false);
        stats.addView(pStat, new LinearLayout.LayoutParams(0, 112, 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0,112,1);
        sp.setMargins(10,0,0,0); stats.addView(sStat, sp);
        root.addView(stats);

        root.addView(sectionTitle("QUICK ACTIONS"));

        LinearLayout grid1 = row();
        LinearLayout prod = actionCard("▣", "PRODUCTS / PARTS", "View and manage products", RED);
        LinearLayout serv = actionCard("⚒", "SERVICES / LABOR", "View and manage services", BLUE);
        grid1.addView(prod, new LinearLayout.LayoutParams(0, 170, 1));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0,170,1);
        mp.setMargins(10,0,0,0); grid1.addView(serv, mp);
        root.addView(grid1);

        LinearLayout grid2 = row();
        LinearLayout addP = actionCard("+", "ADD PRODUCT", "Add a new product or part", GREEN);
        LinearLayout addS = actionCard("+", "ADD SERVICE", "Add a new service or labor item", ORANGE);
        grid2.addView(addP, new LinearLayout.LayoutParams(0, 170, 1));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0,170,1);
        ap.setMargins(10,0,0,0); grid2.addView(addS, ap);
        root.addView(grid2);

        root.addView(sectionTitle("TOOLS"));
        LinearLayout tools = row();
        String[] labels = {"Transactions", "Reports", "Customers", "Settings"};
        String[] icons = {"☷", "▥", "●●", "⚙"};
        for (int i=0;i<labels.length;i++) {
            final int idx=i;
            LinearLayout c = box(CARD, Color.rgb(35,39,45));
            c.setGravity(Gravity.CENTER);
            TextView ic = tv(icons[i], 24, WHITE, true); ic.setGravity(Gravity.CENTER);
            TextView lb = tv(labels[i], 12, WHITE, false); lb.setGravity(Gravity.CENTER);
            c.addView(ic, new LinearLayout.LayoutParams(-1,42));
            c.addView(lb, new LinearLayout.LayoutParams(-1,30));
            if(i==3) c.setOnClickListener(v -> showSettings());
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,100,1);
            if(i>0) tp.setMargins(8,0,0,0);
            tools.addView(c,tp);
        }
        root.addView(tools);

        TextView footer = tv("KURT MOTOSHOP V.1\nSimple  •  Offline  •  Reliable\n\nBUILT FOR BIKERS", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(10,22,10,22);
        root.addView(footer);

        refreshCounts();
        prod.setOnClickListener(v -> showInventory("Products / Parts"));
        serv.setOnClickListener(v -> showInventory("Services / Labor"));
        addP.setOnClickListener(v -> addItem(true));
        addS.setOnClickListener(v -> addItem(false));
    }

    private LinearLayout statCard(String icon, String title, int accent, boolean product) {
        LinearLayout c = box(CARD, accent);
        LinearLayout r = row();
        TextView ic = tv(icon, 27, WHITE, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(bg(Color.rgb(30,30,34), 50, 0, accent));
        r.addView(ic, new LinearLayout.LayoutParams(48,48));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL); texts.setPadding(10,0,0,0);
        TextView t=tv(title,10,MUTED,true);
        TextView n=tv("0",27,WHITE,true);
        if(product) productCount=n; else serviceCount=n;
        texts.addView(t); texts.addView(n);
        r.addView(texts, new LinearLayout.LayoutParams(0,-2,1));
        c.addView(r);
        return c;
    }

    private LinearLayout actionCard(String icon, String title, String desc, int accent) {
        LinearLayout c = box(Color.rgb(12,15,18), accent);
        TextView i = tv(icon, 38, accent, true); i.setGravity(Gravity.CENTER);
        TextView t = tv(title, 16, WHITE, true); t.setPadding(0,8,0,2);
        TextView d = tv(desc, 12, MUTED, false); d.setMaxLines(2);
        c.addView(i, new LinearLayout.LayoutParams(-1,52));
        c.addView(t); c.addView(d);
        return c;
    }

    private void refreshCounts() {
        productCount.setText(String.valueOf(prefs.getInt("products", 0)));
        serviceCount.setText(String.valueOf(prefs.getInt("services", 0)));
    }

    private void addItem(boolean product) {
        EditText input = new EditText(this);
        input.setHint(product ? "Product / Part name" : "Service / Labor name");
        input.setTextColor(WHITE); input.setHintTextColor(MUTED);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(product ? "ADD PRODUCT" : "ADD SERVICE")
                .setView(input)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("ADD", (x,w) -> {
                    String key = product ? "products" : "services";
                    prefs.edit().putInt(key, prefs.getInt(key,0)+1).apply();
                    refreshCounts();
                    Toast.makeText(this, "Added to local inventory", Toast.LENGTH_SHORT).show();
                }).create();
        d.show();
    }

    private void showInventory(String title) {
        int n = title.startsWith("Products") ? prefs.getInt("products",0) : prefs.getInt("services",0);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(String.format(Locale.US, "Total items: %d\n\nInventory is stored locally for offline use.", n))
                .setPositiveButton("OK", null)
                .show();
    }

    private void showSettings() {
        new AlertDialog.Builder(this)
                .setTitle("KURT MOTOSHOP V.1")
                .setMessage("Offline inventory mode is enabled.\n\nVersion 1.0\nLocal storage: ON")
                .setPositiveButton("OK", null)
                .show();
    }
}
