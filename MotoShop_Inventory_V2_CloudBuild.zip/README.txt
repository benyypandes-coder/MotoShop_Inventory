MotoShop Inventory V2
- Dark racing/cyber UI
- Products / Parts
- Services / Labor
- Brand, Model, Name, Price, Stock
- Offline local storage
- Add product/service dialogs
- Dashboard statistics

Build: GitHub Actions workflow included.
