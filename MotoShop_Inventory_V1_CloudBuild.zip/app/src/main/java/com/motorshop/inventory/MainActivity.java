package com.motorshop.inventory;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list;
    ArrayList<String> products = new ArrayList<>();
    ArrayList<String> services = new ArrayList<>();

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    TextView tv(String s, int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.DKGRAY); t.setPadding(dp(12),dp(10),dp(12),dp(10)); return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        load();
        showDashboard();
    }

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        TextView head=tv(title,22); head.setTextColor(Color.WHITE); head.setBackgroundColor(Color.rgb(20,20,20));
        head.setPadding(dp(16),dp(18),dp(16),dp(18)); root.addView(head);
        setContentView(root);
    }

    void showDashboard(){
        base("🏍️ MotoShop Inventory");
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(10),dp(10),dp(10),dp(10));

        grid.addView(tv("Offline Inventory • Version 1.0",16));
        grid.addView(tv("Products: "+products.size()+"    Services: "+services.size(),18));

        Button p=btn("📦  PRODUCTS / PARTS");
        p.setOnClickListener(v->showProducts());
        grid.addView(p);

        Button s=btn("🔧  SERVICES / LABOR");
        s.setOnClickListener(v->showServices());
        grid.addView(s);

        Button a=btn("➕  ADD PRODUCT");
        a.setOnClickListener(v->addProduct());
        grid.addView(a);

        Button x=btn("➕  ADD SERVICE");
        x.setOnClickListener(v->addService());
        grid.addView(x);

        root.addView(grid);
    }

    void showProducts(){
        base("📦 Products / Parts");
        Button add=btn("➕ Add Product"); add.setOnClickListener(v->addProduct()); root.addView(add);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        for(String p:products){
            TextView item=tv(p,16); item.setBackgroundColor(Color.rgb(245,245,245));
            list.addView(item,new LinearLayout.LayoutParams(-1,dp(80)));
        }
        Button back=btn("← Dashboard"); back.setOnClickListener(v->showDashboard()); root.addView(back);
    }

    void showServices(){
        base("🔧 Services / Labor");
        Button add=btn("➕ Add Service"); add.setOnClickListener(v->addService()); root.addView(add);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        for(String s:services) list.addView(tv(s,16));
        Button back=btn("← Dashboard"); back.setOnClickListener(v->showDashboard()); root.addView(back);
    }

    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); return e;
    }

    void addProduct(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText brand=field("Brand"); EditText name=field("Product / Part Name");
        EditText model=field("Model / Compatibility"); EditText cat=field("Category");
        EditText price=field("Selling Price"); EditText stock=field("Stock Quantity");
        EditText storage=field("Storage Location / Rack");
        box.addView(brand);box.addView(name);box.addView(model);box.addView(cat);
        box.addView(price);box.addView(stock);box.addView(storage);
        new AlertDialog.Builder(this).setTitle("Add Product").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                String x=brand.getText()+" | "+name.getText()+" | "+model.getText()
                    +" | "+cat.getText()+" | ₱"+price.getText()+" | Stock: "+stock.getText()
                    +" | "+storage.getText();
                products.add(x); save(); showProducts();
            }).show();
    }

    void addService(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText name=field("Service / Labor Name"); EditText model=field("Motorcycle / Model");
        EditText price=field("Labor Price");
        box.addView(name);box.addView(model);box.addView(price);
        new AlertDialog.Builder(this).setTitle("Add Service / Labor").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                services.add(name.getText()+" | "+model.getText()+" | Labor: ₱"+price.getText());
                save(); showServices();
            }).show();
    }

    void save(){
        getPreferences(0).edit()
            .putString("products", String.join("\n",products))
            .putString("services", String.join("\n",services)).apply();
    }

    void load(){
        String p=getPreferences(0).getString("products","");
        String s=getPreferences(0).getString("services","");
        if(!p.isEmpty()) products.addAll(Arrays.asList(p.split("\n")));
        if(!s.isEmpty()) services.addAll(Arrays.asList(s.split("\n")));
    }
}
