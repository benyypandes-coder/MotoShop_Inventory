MotoShop Inventory - Version 1.0
Offline Android inventory starter for a motorcycle parts/accessories/service shop.

Features:
- Dashboard
- Products/Parts: brand, name, model, category, price, stock, storage
- Services/Labor: name, model, labor price
- Local offline storage
- Add product/service

Open the project in Android Studio and Build > Build APK(s).
